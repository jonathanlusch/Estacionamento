/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author 04928683013
 */

public class Motorista {
    private int IdMotorista;
    private String nome;
    private boolean homem;
    private int RG;
    private int CPF;
    private int celular;
    private String email;
    private String senha;

    public int getIdMotorista() {
        return IdMotorista;
    }

    public void setIdMotorista(int IdMotorista) {
        this.IdMotorista = IdMotorista;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isHomem() {
        return homem;
    }

    public void setHomem(boolean homem) {
        this.homem = homem;
    }

    public int getRG() {
        return RG;
    }

    public void setRG(int RG) {
        this.RG = RG;
    }

    public int getCPF() {
        return CPF;
    }

    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    public int getCelular() {
        return celular;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

}
